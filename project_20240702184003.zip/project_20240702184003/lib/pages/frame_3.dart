import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class Frame3 extends StatelessWidget {
  const Frame3({super.key});

  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: const BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: const EdgeInsets.fromLTRB(0, 48, 0, 36),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            SizedBox(
              width: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.fromLTRB(19, 0, 20, 31),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 7,
                          height: 14,
                          child: SizedBox(
                            width: 7,
                            height: 14,
                            child: SvgPicture.asset(
                              'assets/vectors/vector_40_x2.svg',
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.fromLTRB(0, 5, 0, 4),
                          child: SizedBox(
                            width: 19,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: const EdgeInsets.fromLTRB(0, 0, 2, 0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF424242),
                                      borderRadius: BorderRadius.circular(41),
                                    ),
                                    child: const SizedBox(
                                      width: 5,
                                      height: 5,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: const EdgeInsets.fromLTRB(0, 0, 2, 0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF424242),
                                      borderRadius: BorderRadius.circular(41),
                                    ),
                                    child: const SizedBox(
                                      width: 5,
                                      height: 5,
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF424242),
                                    borderRadius: BorderRadius.circular(41),
                                  ),
                                  child: const SizedBox(
                                    width: 5,
                                    height: 5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(19, 0, 20, 9),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFFDBF2E6),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(11, 8, 20, 7),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 0, 24, 0),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFFFFFF),
                                          borderRadius: BorderRadius.circular(15),
                                        ),
                                        child: SizedBox(
                                          height: 115,
                                          child: Container(
                                            width: 115,
                                            height: 115,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(15),
                                            ),
                                            child: Positioned(
                                              left: 7,
                                              right: 3,
                                              bottom: -35,
                                              child: Container(
                                                decoration: const BoxDecoration(
                                                  image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: AssetImage(
                                                      'assets/images/pngwing_2.png',
                                                    ),
                                                  ),
                                                ),
                                                child: const SizedBox(
                                                  width: 105,
                                                  height: 135,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 17, 6, 25),
                                      child: Stack(
                                        children: [
                                          SizedBox(
                                            width: double.infinity,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: const EdgeInsets.fromLTRB(1, 0, 0.2, 21),
                                                  child: RichText(
                                                    text: TextSpan(
                                                      style: GoogleFonts.getFont(
                                                        'Roboto Condensed',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 14,
                                                        color: const Color(0xFF7A7A7A),
                                                      ),
                                                      children: [
                                                        TextSpan(
                                                          text: 'Placa Solar',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto Condensed',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 14,
                                                            height: 1.3,
                                                            color: const Color(0xFF747373),
                                                          ),
                                                        ),
                                                        const TextSpan(
                                                          text: ' ',
                                                        ),
                                                        TextSpan(
                                                          text: 'NJ9',
                                                          style: GoogleFonts.getFont(
                                                            'Roboto Condensed',
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 14,
                                                            height: 1.3,
                                                            color: const Color(0xFF5B5B5B),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xFFDBDBDB),
                                                    borderRadius: BorderRadius.circular(12),
                                                  ),
                                                  child: Container(
                                                    padding: const EdgeInsets.fromLTRB(0, 3, 6.2, 22),
                                                    child: Text(
                                                      'Captação',
                                                      style: GoogleFonts.getFont(
                                                        'Roboto Condensed',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 9,
                                                        color: const Color(0xFFFFFFFF),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: 1,
                                            top: 13,
                                            child: SizedBox(
                                              height: 12,
                                              child: Text(
                                                'Status -',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 10,
                                                  color: const Color(0x8A7A7A7A),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 54, 0, 25),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFDBDBDB),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Container(
                                          padding: const EdgeInsets.fromLTRB(0, 3, 3.8, 22),
                                          child: Text(
                                            'Saúde',
                                            style: GoogleFonts.getFont(
                                              'Roboto Condensed',
                                              fontWeight: FontWeight.w500,
                                              fontSize: 9,
                                              color: const Color(0xFFFFFFFF),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              right: 0,
                              bottom: 10,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFFFFF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: SizedBox(
                                  width: 90,
                                  height: 36,
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(16, 10, 18.2, 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 9, 0),
                                          child: SizedBox(
                                            width: 19,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_31_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 1, 0, 0),
                                          child: Opacity(
                                            opacity: 0.8,
                                            child: Text(
                                              '100%',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 13,
                                                color: const Color(0xFF52A77A),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              right: 96,
                              bottom: 10,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFFFFF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: SizedBox(
                                  width: 90,
                                  height: 36,
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(13, 10, 0, 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 12, 0),
                                          child: Opacity(
                                            opacity: 0.8,
                                            child: SizedBox(
                                              width: 16,
                                              height: 16,
                                              child: SvgPicture.asset(
                                                'assets/vectors/group_1_x2.svg',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 1, 0, 0),
                                          child: Opacity(
                                            opacity: 0.8,
                                            child: Text(
                                              '100%',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 13,
                                                color: const Color(0xFF52A77A),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(19, 0, 18, 28),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Container(
                            margin: const EdgeInsets.fromLTRB(0, 0, 14, 0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: const EdgeInsets.fromLTRB(0, 0, 0, 14),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFDBF2E6),
                                      borderRadius: BorderRadius.circular(25),
                                    ),
                                    child: Container(
                                      padding: const EdgeInsets.fromLTRB(20, 17, 20, 18),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: const EdgeInsets.fromLTRB(0, 0, 32, 0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xFFFFFFFF),
                                                    borderRadius: BorderRadius.circular(39),
                                                  ),
                                                  child: Container(
                                                    width: 49,
                                                    height: 49,
                                                    padding: const EdgeInsets.fromLTRB(17, 16, 16, 17),
                                                    child: Opacity(
                                                      opacity: 0.7,
                                                      child: SizedBox(
                                                        width: 16,
                                                        height: 16,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_8_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: const EdgeInsets.fromLTRB(0, 11, 0, 20),
                                                child: Opacity(
                                                  opacity: 0.8,
                                                  child: Text(
                                                    '20 Kwh',
                                                    style: GoogleFonts.getFont(
                                                      'Roboto Condensed',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 15,
                                                      color: const Color(0xFF121212),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Positioned(
                                            right: 6.1,
                                            bottom: 10,
                                            child: SizedBox(
                                              height: 14,
                                              child: Text(
                                                '1 hora',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 12,
                                                  color: const Color(0xFF838383),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFDBF2E6),
                                    borderRadius: BorderRadius.circular(25),
                                  ),
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(20, 17, 17, 33),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 0, 16),
                                          child: Align(
                                            alignment: Alignment.topLeft,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: const EdgeInsets.fromLTRB(0, 0, 15.7, 0),
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: const Color(0xFFFFFFFF),
                                                      borderRadius: BorderRadius.circular(39),
                                                    ),
                                                    child: Container(
                                                      width: 49,
                                                      height: 49,
                                                      padding: const EdgeInsets.fromLTRB(15, 14, 14, 15),
                                                      child: SizedBox(
                                                        width: 20,
                                                        height: 20,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_6_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: const EdgeInsets.fromLTRB(0, 7, 0, 6),
                                                  child: Opacity(
                                                    opacity: 0.8,
                                                    child: Text(
                                                      'Status de limpeza',
                                                      textAlign: TextAlign.right,
                                                      style: GoogleFonts.getFont(
                                                        'Roboto Condensed',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 15,
                                                        color: const Color(0xFF121212),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 0, 8),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFFFFFFF),
                                              borderRadius: BorderRadius.circular(6),
                                            ),
                                            child: SizedBox(
                                              width: 138,
                                              height: 39,
                                              child: Container(
                                                width: 138,
                                                height: 39,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(6),
                                                ),
                                                child: Positioned(
                                                  left: -2,
                                                  bottom: 0,
                                                  child: Container(
                                                    decoration: const BoxDecoration(
                                                      color: Color(0xFFFF5C28),
                                                    ),
                                                    child: const SizedBox(
                                                      width: 95,
                                                      height: 39,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 12, 0),
                                          child: Align(
                                            alignment: Alignment.topCenter,
                                            child: Opacity(
                                              opacity: 0.8,
                                              child: Text(
                                                'Limpe sua placa',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 13,
                                                  color: const Color(0xFF828282),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: Container(
                            margin: const EdgeInsets.fromLTRB(0, 4, 0, 6),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  margin: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFDBF2E6),
                                      borderRadius: BorderRadius.circular(25),
                                    ),
                                    child: Container(
                                      padding: const EdgeInsets.fromLTRB(12, 14, 13, 14),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Positioned(
                                            left: 0,
                                            right: 0,
                                            bottom: 4,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFFFFFFF),
                                                borderRadius: BorderRadius.circular(12),
                                              ),
                                              child: Container(
                                                width: 144,
                                                height: 36,
                                                padding: const EdgeInsets.fromLTRB(15, 7, 15, 8.3),
                                                child: SizedBox(
                                                  width: 20.8,
                                                  height: 20.8,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/group_2_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: double.infinity,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: const EdgeInsets.fromLTRB(0, 0, 0, 12),
                                                  child: Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: const EdgeInsets.fromLTRB(0, 0, 15, 0),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: const Color(0xFFFFFFFF),
                                                              borderRadius: BorderRadius.circular(39),
                                                            ),
                                                            child: Container(
                                                              width: 49,
                                                              height: 49,
                                                              padding: const EdgeInsets.fromLTRB(14, 16, 13, 17),
                                                              child: Opacity(
                                                                opacity: 0.7,
                                                                child: SizedBox(
                                                                  width: 22,
                                                                  height: 16,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/vector_39_x2.svg',
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: const EdgeInsets.fromLTRB(0, 19, 0, 12),
                                                          child: Opacity(
                                                            opacity: 0.8,
                                                            child: Text(
                                                              'Clima',
                                                              style: GoogleFonts.getFont(
                                                                'Roboto Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 15,
                                                                color: const Color(0xFF121212),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: const EdgeInsets.fromLTRB(0, 0, 0, 16),
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: const Color(0xFFFFFFFF),
                                                      borderRadius: BorderRadius.circular(12),
                                                    ),
                                                    child: Container(
                                                      padding: const EdgeInsets.fromLTRB(13, 9, 0, 9),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          SizedBox(
                                                            width: 24,
                                                            height: 18,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/group_x2.svg',
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: const EdgeInsets.fromLTRB(0, 3, 0, 0),
                                                            child: Text(
                                                              'Nublado ',
                                                              style: GoogleFonts.getFont(
                                                                'Roboto Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 13,
                                                                color: const Color(0xFF52A77A),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: const EdgeInsets.fromLTRB(40.9, 0, 0, 0),
                                                  child: Align(
                                                    alignment: Alignment.topCenter,
                                                    child: Text(
                                                      'Sol entre nuvens',
                                                      style: GoogleFonts.getFont(
                                                        'Roboto Condensed',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 13,
                                                        color: const Color(0xFF52A77A),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFDBF2E6),
                                    borderRadius: BorderRadius.circular(25),
                                  ),
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(12, 22, 12, 24),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 5, 0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFFFFFFF),
                                                borderRadius: BorderRadius.circular(12),
                                              ),
                                              child: Container(
                                                padding: const EdgeInsets.fromLTRB(10, 13, 10, 10),
                                                child: Text(
                                                  'Ligada',
                                                  style: GoogleFonts.getFont(
                                                    'Roboto Condensed',
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 13,
                                                    color: const Color(0xFF52A77A),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 24,
                                          height: 38,
                                          child: SvgPicture.asset(
                                            'assets/vectors/vector_30_x2.svg',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF6F6FA),
                      borderRadius: BorderRadius.circular(29),
                    ),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(19, 22, 20, 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: const EdgeInsets.fromLTRB(0, 0, 7, 20),
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(0xFFD9D9D9),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: const SizedBox(
                                width: 57,
                                height: 9,
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFFFFF),
                              borderRadius: BorderRadius.circular(21),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  left: 9,
                                  top: 20,
                                  child: SizedBox(
                                    width: 241.8,
                                    height: 126.2,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_3_x2.svg',
                                    ),
                                  ),
                                ),
                          Container(
                                  padding: const EdgeInsets.fromLTRB(13, 33, 13, 39),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 4, 0),
                                            child: Container(
                                              decoration: const BoxDecoration(
                                                color: Color(0xFFD9D9D9),
                                              ),
                                              child: const SizedBox(
                                                width: 1,
                                                height: 140,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 1, 9.6, 127),
                                            child: Text(
                                              'Rentabilidade',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 10,
                                                color: const Color(0xFFA0A0A0),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 67, 37, 68),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: const Color(0xFF2D8A01),
                                                borderRadius: BorderRadius.circular(5.5),
                                              ),
                                              child: const SizedBox(
                                                width: 5,
                                                height: 5,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 101, 56, 34),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: const Color(0xFF2D8A01),
                                                borderRadius: BorderRadius.circular(5.5),
                                              ),
                                              child: const SizedBox(
                                                width: 5,
                                                height: 5,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 26, 36, 109),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: const Color(0xFF2D8A01),
                                                borderRadius: BorderRadius.circular(5.5),
                                              ),
                                              child: const SizedBox(
                                                width: 5,
                                                height: 5,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 60, 29, 75),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: const Color(0xFF2D8A01),
                                                borderRadius: BorderRadius.circular(5.5),
                                              ),
                                              child: const SizedBox(
                                                width: 5,
                                                height: 5,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 19, 0, 98),
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: const EdgeInsets.fromLTRB(0, 0, 14.4, 6),
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: const Color(0xFF2D8A01),
                                                      borderRadius: BorderRadius.circular(5.5),
                                                    ),
                                                    child: const SizedBox(
                                                      width: 5,
                                                      height: 5,
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: const EdgeInsets.fromLTRB(3, 0, 0, 0),
                                                  child: Text(
                                                    '40%',
                                                    style: GoogleFonts.getFont(
                                                      'Roboto Condensed',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 10,
                                                      color: const Color(0xFF52A77A),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      Positioned(
                                        left: 0,
                                        right: 5,
                                        bottom: 0,
                                        child: Container(
                                          decoration: const BoxDecoration(
                                            color: Color(0xFFD9D9D9),
                                          ),
                                          child: const SizedBox(
                                            width: 325,
                                            height: 1,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                decoration: const BoxDecoration(
                  color: Color(0xFFF8F8FB),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x26000000),
                      offset: Offset(0, -4),
                      blurRadius: 5,
                    ),
                  ],
                ),
                child: SizedBox(
                  width: 395,
                  height: 85,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(0, 28, 0, 27),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 30,
                          height: 30,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_32_x2.svg',
                          ),
                        ),
                        SizedBox(
                          width: 22,
                          height: 30,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_16_x2.svg',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}