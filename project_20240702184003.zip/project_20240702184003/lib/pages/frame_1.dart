import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class Frame1 extends StatelessWidget {
  const Frame1({super.key});

  @override
  Widget build(BuildContext context) {
    return 
    Stack(
      children: [
        Container(
          decoration: const BoxDecoration(
            color: Color(0xFFFFFFFF),
          ),
          child: SizedBox(
            width: double.infinity,
            child: Container(
              padding: const EdgeInsets.fromLTRB(35, 95.5, 35, 43.3),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 71.2),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0x210FA958),
                          borderRadius: BorderRadius.circular(80),
                        ),
                        child: Container(
                          width: 45,
                          height: 44.3,
                          padding: const EdgeInsets.fromLTRB(15, 11.2, 17, 12.1),
                          child: SizedBox(
                            width: 12.9,
                            height: 21,
                            child: SizedBox(
                              width: 12.9,
                              height: 21,
                              child: SvgPicture.asset(
                                'assets/vectors/fe_arrow_up_2_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(3, 0, 0, 76.6),
                    child: Stack(
                      children: [
                        Positioned(
                          left: 14,
                          top: 172.9,
                          child: SizedBox(
                            width: 10,
                            height: 11.8,
                            child: SvgPicture.asset(
                              'assets/vectors/vector_27_x2.svg',
                            ),
                          ),
                        ),
                  Stack(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 0, 18.1, 46),
                                    child: Text(
                                      'Login',
                                      style: GoogleFonts.getFont(
                                        'Roboto Condensed',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 48,
                                        color: const Color(0xFF0FA958),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 12.8),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0x260FA958),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Container(
                                        padding: const EdgeInsets.fromLTRB(10, 13.8, 0, 13.8),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            SizedBox(
                                              width: 19,
                                              height: 14.8,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_9_x2.svg',
                                              ),
                                            ),
                                            Container(
                                              margin: const EdgeInsets.fromLTRB(0, 2.5, 0, 0.3),
                                              child: Text(
                                                'E-mail ',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 10,
                                                  color: const Color(0x63000000),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 42.3),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0x260FA958),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Container(
                                        padding: const EdgeInsets.fromLTRB(0, 16.1, 217.4, 14.2),
                                        child: Text(
                                          'Senha',
                                          style: GoogleFonts.getFont(
                                            'Roboto Condensed',
                                            fontWeight: FontWeight.w500,
                                            fontSize: 10,
                                            color: const Color(0x63000000),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 0, 10.7, 40.2),
                                    child: Text(
                                      'Login',
                                      style: GoogleFonts.getFont(
                                        'Roboto Condensed',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16,
                                        color: const Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 0, 14.4, 0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0.4, 0, 0),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: const EdgeInsets.fromLTRB(0, 1, 3, 4),
                                                width: 10,
                                                height: 10,
                                                decoration: BoxDecoration(
                                                  border: Border.all(color: const Color(0xFF000000)),
                                                ),
                                              ),
                                              Text(
                                                'Lembre de mim',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 13,
                                                  color: const Color(0xFF000000),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 0, 0.4),
                                          child: Text(
                                            'Esqueceu a senha?',
                                            style: GoogleFonts.getFont(
                                              'Roboto Condensed',
                                              fontWeight: FontWeight.w500,
                                              fontSize: 13,
                                              color: const Color(0xFF0FA958),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              left: 100,
                              top: 53,
                              child: SizedBox(
                                height: 18,
                                child: Text(
                                  'Seja bem vindo!',
                                  style: GoogleFonts.getFont(
                                    'Roboto Condensed',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 15,
                                    color: const Color(0xFF000000),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(3, 0, 0, 24),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 9, 4, 6),
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: Color(0xFF000000),
                                ),
                                child: const SizedBox(
                                  width: 82,
                                  height: 1,
                                ),
                              ),
                            ),
                            Text(
                              'Não tenho uma conta',
                              style: GoogleFonts.getFont(
                                'Roboto Condensed',
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                                color: const Color(0xFF000000),
                              ),
                            ),
                          ],
                        ),
                        Container(
                          margin: const EdgeInsets.fromLTRB(0, 9, 0, 6),
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Color(0xFF000000),
                            ),
                            child: const SizedBox(
                              width: 87,
                              height: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(5, 0, 0, 86.6),
                    child: SizedBox(
                      width: 236,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.fromLTRB(0, 0, 34, 0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(48),
                              color: const Color(0xFFFFFFFF),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x33000000),
                                  offset: Offset(2, 2),
                                  blurRadius: 2.5,
                                ),
                              ],
                            ),
                            child: Container(
                              width: 55,
                              height: 54.2,
                              padding: const EdgeInsets.fromLTRB(13, 11.8, 13, 13.8),
                              child: SizedBox(
                                width: 29,
                                height: 28.6,
                                child: SizedBox(
                                  width: 29,
                                  height: 28.6,
                                  child: SvgPicture.asset(
                                    'assets/vectors/container_x2.svg',
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.fromLTRB(0, 0, 37, 0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(48),
                              color: const Color(0xFFFFFFFF),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x33000000),
                                  offset: Offset(2, 2),
                                  blurRadius: 2.5,
                                ),
                              ],
                            ),
                            child: Container(
                              width: 55,
                              height: 54.2,
                              padding: const EdgeInsets.fromLTRB(14, 12.8, 13, 13.8),
                              child: SizedBox(
                                width: 28,
                                height: 27.6,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_3_x2.svg',
                                ),
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(48),
                              color: const Color(0xFFFFFFFF),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x33000000),
                                  offset: Offset(2, 2),
                                  blurRadius: 2.5,
                                ),
                              ],
                            ),
                            child: Container(
                              width: 55,
                              height: 54.2,
                              padding: const EdgeInsets.fromLTRB(16, 11.8, 15, 14.8),
                              child: SizedBox(
                                width: 24,
                                height: 27.6,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_14_x2.svg',
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(0, 0, 17.8, 0),
                    child: RichText(
                      text: TextSpan(
                        style: GoogleFonts.getFont(
                          'Roboto Condensed',
                          fontWeight: FontWeight.w300,
                          fontSize: 14,
                          color: const Color(0xFF000000),
                        ),
                        children: [
                          TextSpan(
                            text: 'Você já tem uma conta?',
                            style: GoogleFonts.getFont(
                              'Roboto Condensed',
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1.3,
                              color: const Color(0xA1000000),
                            ),
                          ),
                          TextSpan(
                            text: ' ',
                            style: GoogleFonts.getFont(
                              'Roboto Condensed',
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1.3,
                              color: const Color(0xFF0FA958),
                            ),
                          ),
                          TextSpan(
                            text: 'Login',
                            style: GoogleFonts.getFont(
                              'Roboto Condensed',
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              height: 1.3,
                              color: const Color(0xFF0FA958),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          left: 38,
          right: 35,
          bottom: 357,
          child: SizedBox(
            width: 312,
            height: 47,
            child: Stack(
              children: [
                Positioned(
                  right: -279.6,
                  top: -555,
                  child: Transform(
                    transform: Matrix4.identity()..rotationZ(-0.5808177728),
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage(
                            'assets/images/pngwing_1.png',
                          ),
                        ),
                      ),
                      child: const SizedBox(
                        width: 460.6,
                        height: 413.2,
                      ),
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xB50B8344),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(0, 14, 1.7, 14),
                    child: Text(
                      'Login',
                      style: GoogleFonts.getFont(
                        'Roboto Condensed',
                        fontWeight: FontWeight.w500,
                        fontSize: 16,
                        color: const Color(0xFFFFFFFF),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}