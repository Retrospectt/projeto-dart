import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class Frame5 extends StatelessWidget {
  const Frame5({super.key});

  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: const BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: const EdgeInsets.fromLTRB(0, 48, 0, 0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: const EdgeInsets.fromLTRB(19, 0, 19, 19),
              child: Align(
                alignment: Alignment.topLeft,
                child: SizedBox(
                  width: 195.2,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 9),
                        width: 7,
                        height: 14,
                        child: SizedBox(
                          width: 7,
                          height: 14,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_22_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child: Text(
                          'Perfil',
                          style: GoogleFonts.getFont(
                            'Roboto Condensed',
                            fontWeight: FontWeight.w500,
                            fontSize: 20,
                            color: const Color(0xFF000000),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(19, 0, 19, 7),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFDBF2E6),
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(13, 14, 24, 15),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Container(
                                margin: const EdgeInsets.fromLTRB(0, 0, 15, 0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(64),
                                    image: const DecorationImage(
                                      fit: BoxFit.cover,
                                      image: AssetImage(
                                        'assets/images/rectangle_96.png',
                                      ),
                                    ),
                                  ),
                                  child: Container(
                                    height: 74,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 23, 70.8, 24),
                              child: Text(
                                'Chris Bumstead',
                                style: GoogleFonts.getFont(
                                  'Adamina',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 20,
                                  color: const Color(0xFF444444),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 29, 0, 29),
                              child: SizedBox(
                                width: 8,
                                height: 16,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_7_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        left: 89,
                        bottom: 18,
                        child: SizedBox(
                          height: 12,
                          child: Text(
                            '@cbum',
                            style: GoogleFonts.getFont(
                              'Roboto Condensed',
                              fontWeight: FontWeight.w500,
                              fontSize: 10,
                              color: const Color(0xD4444444),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(18, 0, 20, 25),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFDBF2E6),
                  borderRadius: BorderRadius.circular(33),
                ),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(0, 2, 3, 2),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 9, 0, 8),
                        child: SizedBox(
                          width: 18,
                          height: 13,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_2_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 9, 0, 8),
                        child: SizedBox(
                          width: 17,
                          height: 13,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_33_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFF52A77A),
                          borderRadius: BorderRadius.circular(82),
                        ),
                        child: Container(
                          width: 120,
                          height: 30,
                          padding: const EdgeInsets.fromLTRB(4, 9, 0, 8),
                          child: SizedBox(
                            width: 14,
                            height: 13,
                            child: SvgPicture.asset(
                              'assets/vectors/vector_28_x2.svg',
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(19, 0, 19, 13),
              child: Align(
                alignment: Alignment.topLeft,
                child: SizedBox(
                  width: 333,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 3, 9, 1),
                        child: SizedBox(
                          width: 318,
                          child: Text(
                            'Configurações',
                            style: GoogleFonts.getFont(
                              'Roboto Condensed',
                              fontWeight: FontWeight.w500,
                              fontSize: 15,
                              color: const Color(0xFF000000),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 6,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 0, 0, 2),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFF000000),
                                  borderRadius: BorderRadius.circular(64),
                                ),
                                child: const SizedBox(
                                  width: 6,
                                  height: 6,
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 0, 0, 2),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFF000000),
                                  borderRadius: BorderRadius.circular(64),
                                ),
                                child: const SizedBox(
                                  width: 6,
                                  height: 6,
                                ),
                              ),
                            ),
                            Container(
                              decoration: BoxDecoration(
                                color: const Color(0xFF000000),
                                borderRadius: BorderRadius.circular(64),
                              ),
                              child: const SizedBox(
                                width: 6,
                                height: 6,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(18, 0, 20, 7),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFDBF2E6),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(0, 19, 0, 13),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.fromLTRB(14, 0, 23, 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: SizedBox(
                                width: 305,
                                child: Text(
                                  'Meus aparelhos',
                                  style: GoogleFonts.getFont(
                                    'Adamina',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 15,
                                    color: const Color(0xFF444444),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 3, 0, 7),
                              child: SizedBox(
                                width: 5,
                                height: 10,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_26_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 17),
                        child: Container(
                          decoration: const BoxDecoration(
                            color: Color(0xFFFFFFFF),
                          ),
                          child: const SizedBox(
                            width: 357,
                            height: 2,
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(14, 0, 23, 15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: SizedBox(
                                width: 305,
                                child: Text(
                                  'E-mail',
                                  style: GoogleFonts.getFont(
                                    'Adamina',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 15,
                                    color: const Color(0xFF444444),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 3, 0, 7),
                              child: SizedBox(
                                width: 5,
                                height: 10,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_24_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 11),
                        child: Container(
                          decoration: const BoxDecoration(
                            color: Color(0xFFFFFFFF),
                          ),
                          child: const SizedBox(
                            width: 357,
                            height: 2,
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(14, 0, 23, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: SizedBox(
                                width: 305,
                                child: Text(
                                  'Senha',
                                  style: GoogleFonts.getFont(
                                    'Adamina',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 15,
                                    color: const Color(0xFF444444),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 4, 0, 6),
                              child: SizedBox(
                                width: 5,
                                height: 10,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_13_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(18, 0, 20, 7),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFDBF2E6),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(0, 19, 0, 9),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.fromLTRB(14, 0, 23, 11),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: SizedBox(
                                width: 305,
                                child: Text(
                                  'Idioma',
                                  style: GoogleFonts.getFont(
                                    'Adamina',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 15,
                                    color: const Color(0xFF444444),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 2, 0, 8),
                              child: SizedBox(
                                width: 5,
                                height: 10,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_1_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 14),
                        child: Container(
                          decoration: const BoxDecoration(
                            color: Color(0xFFFFFFFF),
                          ),
                          child: const SizedBox(
                            width: 357,
                            height: 2,
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(14, 0, 23, 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: SizedBox(
                                width: 305,
                                child: Text(
                                  'Problemas?',
                                  style: GoogleFonts.getFont(
                                    'Adamina',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 15,
                                    color: const Color(0xFF444444),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 4, 0, 6),
                              child: SizedBox(
                                width: 5,
                                height: 10,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_23_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(0, 0, 0, 19),
                        child: Container(
                          decoration: const BoxDecoration(
                            color: Color(0xFFFFFFFF),
                          ),
                          child: const SizedBox(
                            width: 357,
                            height: 2,
                          ),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.fromLTRB(14, 0, 23, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 1, 10, 0),
                              child: SizedBox(
                                width: 305,
                                child: Text(
                                  'Atualizações',
                                  style: GoogleFonts.getFont(
                                    'Adamina',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 15,
                                    color: const Color(0xFF444444),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 0, 0, 11),
                              child: SizedBox(
                                width: 5,
                                height: 10,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_18_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(18, 0, 20, 97),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFDBF2E6),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(14, 20, 14, 16),
                  child: Text(
                    'Sair',
                    style: GoogleFonts.getFont(
                      'Adamina',
                      fontWeight: FontWeight.w400,
                      fontSize: 15,
                      color: const Color(0xFFFF0000),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                color: Color(0xFFF8F8FB),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x26000000),
                    offset: Offset(0, -4),
                    blurRadius: 5,
                  ),
                ],
              ),
              child: Container(
                padding: const EdgeInsets.fromLTRB(0, 23, 0, 23),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.fromLTRB(0, 3, 0, 2),
                      child: SizedBox(
                        width: 34,
                        height: 34,
                        child: SvgPicture.asset(
                          'assets/vectors/vector_x2.svg',
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 30,
                      height: 39,
                      child: SvgPicture.asset(
                        'assets/vectors/vector_15_x2.svg',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}