import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class Frame2 extends StatelessWidget {
  const Frame2({super.key});

  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: const BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: const EdgeInsets.fromLTRB(19, 48, 20, 57),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              left: 11,
              top: 53,
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFFFF),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const SizedBox(
                  width: 115,
                  height: 115,
                ),
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 31),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 7,
                          height: 14,
                          child: SizedBox(
                            width: 7,
                            height: 14,
                            child: SvgPicture.asset(
                              'assets/vectors/vector_34_x2.svg',
                            ),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                          child: SizedBox(
                            width: 14,
                            height: 14,
                            child: SvgPicture.asset(
                              'assets/vectors/vector_38_x2.svg',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 11),
                    child: Stack(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFFDBF2E6),
                            borderRadius: BorderRadius.circular(25),
                          ),
                          child: SizedBox(
                            width: double.infinity,
                            child: Container(
                              padding: const EdgeInsets.fromLTRB(11, 8, 32, 7),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 0, 25, 0),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFFFFFF),
                                          borderRadius: BorderRadius.circular(15),
                                        ),
                                        child: SizedBox(
                                          height: 115,
                                          child: Container(
                                            width: 115,
                                            height: 115,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(15),
                                            ),
                                            child: Positioned(
                                              left: 7,
                                              right: 3,
                                              bottom: -35,
                                              child: Container(
                                                decoration: const BoxDecoration(
                                                  image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: AssetImage(
                                                      'assets/images/pngwing_2.png',
                                                    ),
                                                  ),
                                                ),
                                                child: const SizedBox(
                                                  width: 105,
                                                  height: 135,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 16, 26, 10),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 13.9, 12),
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                RichText(
                                                  text: TextSpan(
                                                    style: GoogleFonts.getFont(
                                                      'Roboto Condensed',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 12,
                                                      color: const Color(0xFF7A7A7A),
                                                    ),
                                                    children: [
                                                      TextSpan(
                                                        text: 'Placa Solar',
                                                        style: GoogleFonts.getFont(
                                                          'Roboto Condensed',
                                                          fontWeight: FontWeight.w500,
                                                          fontSize: 12,
                                                          height: 1.3,
                                                          color: const Color(0xFF747373),
                                                        ),
                                                      ),
                                                      TextSpan(
                                                        text: ' ',
                                                        style: GoogleFonts.getFont(
                                                          'Roboto Condensed',
                                                          fontWeight: FontWeight.w500,
                                                          fontSize: 12,
                                                          height: 1.3,
                                                        ),
                                                      ),
                                                      TextSpan(
                                                        text: 'NJ9',
                                                        style: GoogleFonts.getFont(
                                                          'Roboto Condensed',
                                                          fontWeight: FontWeight.w500,
                                                          fontSize: 12,
                                                          height: 1.3,
                                                          color: const Color(0xFF5B5B5B),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Status -',
                                                    style: GoogleFonts.getFont(
                                                      'Roboto Condensed',
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 10,
                                                      color: const Color(0x8A7A7A7A),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            padding: const EdgeInsets.fromLTRB(0, 0, 0, 15),
                                            child: Stack(
                                              clipBehavior: Clip.none,
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xFFDBDBDB),
                                                    borderRadius: BorderRadius.circular(12),
                                                  ),
                                                  child: Container(
                                                    width: double.infinity,
                                                    padding: const EdgeInsets.fromLTRB(0, 3, 3.8, 22),
                                                    child: Text(
                                                      'Saúde',
                                                      style: GoogleFonts.getFont(
                                                        'Roboto Condensed',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 9,
                                                        color: const Color(0xFFFFFFFF),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  left: 0,
                                                  right: 0,
                                                  bottom: 0,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: const Color(0xFFFFFFFF),
                                                      borderRadius: BorderRadius.circular(12),
                                                    ),
                                                    child: SizedBox(
                                                      width: 90,
                                                      height: 36,
                                                      child: Container(
                                                        padding: const EdgeInsets.fromLTRB(11, 10, 0, 10),
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            SizedBox(
                                                              width: 19,
                                                              height: 16,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_12_x2.svg',
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: const EdgeInsets.fromLTRB(0, 1, 0, 0),
                                                              child: Opacity(
                                                                opacity: 0.8,
                                                                child: Text(
                                                                  '100%',
                                                                  style: GoogleFonts.getFont(
                                                                    'Roboto Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 13,
                                                                    color: const Color(0xFF52A77A),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 29, 0, 29),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFFFFFFF),
                                        borderRadius: BorderRadius.circular(78),
                                      ),
                                      child: Container(
                                        width: 57,
                                        height: 57,
                                        padding: const EdgeInsets.fromLTRB(15, 14, 14, 14),
                                        child: SizedBox(
                                          width: 28,
                                          height: 29,
                                          child: SvgPicture.asset(
                                            'assets/vectors/vector_20_x2.svg',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          right: 128.9,
                          top: 24,
                          child: SizedBox(
                            height: 14,
                            child: RichText(
                              text: TextSpan(
                                style: GoogleFonts.getFont(
                                  'Roboto Condensed',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                  color: const Color(0xFF7A7A7A),
                                ),
                                children: [
                                  TextSpan(
                                    text: 'Placa Solar',
                                    style: GoogleFonts.getFont(
                                      'Roboto Condensed',
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                      height: 1.3,
                                      color: const Color(0xFF747373),
                                    ),
                                  ),
                                  TextSpan(
                                    text: ' ',
                                    style: GoogleFonts.getFont(
                                      'Roboto Condensed',
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                      height: 1.3,
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'NJ9',
                                    style: GoogleFonts.getFont(
                                      'Roboto Condensed',
                                      fontWeight: FontWeight.w500,
                                      fontSize: 12,
                                      height: 1.3,
                                      color: const Color(0xFF5B5B5B),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 151,
                          top: 38,
                          child: SizedBox(
                            height: 12,
                            child: Text(
                              'Status -',
                              style: GoogleFonts.getFont(
                                'Roboto Condensed',
                                fontWeight: FontWeight.w500,
                                fontSize: 10,
                                color: const Color(0x8A7A7A7A),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          right: 32,
                          child: Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFFFFF),
                              borderRadius: BorderRadius.circular(78),
                            ),
                            child: const SizedBox(
                              width: 57,
                              height: 57,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 11),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFFD0D0D0),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(11, 8, 32, 7),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 0, 25, 0),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFFFFFF),
                                          borderRadius: BorderRadius.circular(15),
                                        ),
                                        child: SizedBox(
                                          height: 115,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(15),
                                              color: const Color(0xFF000000),
                                            ),
                                            child: SizedBox(
                                              width: 115,
                                              height: 115,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    left: 7,
                                                    right: 3,
                                                    bottom: -35,
                                                    child: Container(
                                                      decoration: const BoxDecoration(
                                                        image: DecorationImage(
                                                          fit: BoxFit.cover,
                                                          image: AssetImage(
                                                            'assets/images/pngwing_2.png',
                                                          ),
                                                        ),
                                                      ),
                                                      child: const SizedBox(
                                                        width: 105,
                                                        height: 135,
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    decoration: const BoxDecoration(
                                                      color: Color(0xFF000000),
                                                    ),
                                                    child: const SizedBox(
                                                      width: 115,
                                                      height: 115,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 16, 24.7, 25),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          RichText(
                                            text: TextSpan(
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12,
                                                color: const Color(0xFF7A7A7A),
                                              ),
                                              children: [
                                                TextSpan(
                                                  text: 'Placa Solar',
                                                  style: GoogleFonts.getFont(
                                                    'Roboto Condensed',
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 12,
                                                    height: 1.3,
                                                    color: const Color(0xFF747373),
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: ' ',
                                                  style: GoogleFonts.getFont(
                                                    'Roboto Condensed',
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 12,
                                                    height: 1.3,
                                                  ),
                                                ),
                                                TextSpan(
                                                  text: 'NJ9 - 2',
                                                  style: GoogleFonts.getFont(
                                                    'Roboto Condensed',
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 12,
                                                    height: 1.3,
                                                    color: const Color(0xFF5B5B5B),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 0, 12),
                                            child: Align(
                                              alignment: Alignment.topLeft,
                                              child: Text(
                                                'Status -',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 10,
                                                  color: const Color(0x8A7A7A7A),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 1.3, 0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFDBDBDB),
                                                borderRadius: BorderRadius.circular(12),
                                              ),
                                              child: Container(
                                                padding: const EdgeInsets.fromLTRB(0, 3, 3.8, 22),
                                                child: Text(
                                                  'Saúde',
                                                  style: GoogleFonts.getFont(
                                                    'Roboto Condensed',
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 9,
                                                    color: const Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 29, 0, 29),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFFFFFFF),
                                        borderRadius: BorderRadius.circular(78),
                                      ),
                                      child: Container(
                                        width: 57,
                                        height: 57,
                                        padding: const EdgeInsets.fromLTRB(15, 14, 14, 14),
                                        child: SizedBox(
                                          width: 28,
                                          height: 29,
                                          child: SvgPicture.asset(
                                            'assets/vectors/vector_35_x2.svg',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              right: 83,
                              bottom: 10,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFFFFF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: SizedBox(
                                  width: 90,
                                  height: 36,
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(11, 10, 0, 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 9, 0),
                                          child: SizedBox(
                                            width: 19,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_19_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 1, 0, 0),
                                          child: Opacity(
                                            opacity: 0.8,
                                            child: Text(
                                              '100%',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 13,
                                                color: const Color(0xFF838383),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 11),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFFDBF2E6),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(11, 8, 32, 7),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 0, 25, 0),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFFFFFF),
                                          borderRadius: BorderRadius.circular(15),
                                        ),
                                        child: Container(
                                          height: 115,
                                          padding: const EdgeInsets.fromLTRB(17, 17, 17, 17),
                                          child: Container(
                                            decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/pngwing_3.png',
                                                ),
                                              ),
                                            ),
                                            child: const SizedBox(
                                              width: 81,
                                              height: 81,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 16, 26, 25),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text(
                                              'Lâmpada P1',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12,
                                                color: const Color(0xFF747373),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 0, 12),
                                            child: Align(
                                              alignment: Alignment.topLeft,
                                              child: Text(
                                                'Status -',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 10,
                                                  color: const Color(0x8A7A7A7A),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFDBDBDB),
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Container(
                                              padding: const EdgeInsets.fromLTRB(0, 3, 3.8, 22),
                                              child: Text(
                                                'Saúde',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 9,
                                                  color: const Color(0xFFFFFFFF),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 29, 0, 29),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFFFFFFF),
                                        borderRadius: BorderRadius.circular(78),
                                      ),
                                      child: Container(
                                        width: 57,
                                        height: 57,
                                        padding: const EdgeInsets.fromLTRB(15, 14, 14, 14),
                                        child: SizedBox(
                                          width: 28,
                                          height: 29,
                                          child: SvgPicture.asset(
                                            'assets/vectors/vector_11_x2.svg',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              right: 83,
                              bottom: 10,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFFFFF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: SizedBox(
                                  width: 90,
                                  height: 36,
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(11, 10, 0, 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 9, 0),
                                          child: SizedBox(
                                            width: 19,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_29_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 1, 0, 0),
                                          child: Opacity(
                                            opacity: 0.8,
                                            child: Text(
                                              '80%',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 13,
                                                color: const Color(0xFFFFB800),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 11),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFFDBF2E6),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(11, 8, 32, 7),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 0, 25, 0),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFFFFFF),
                                          borderRadius: BorderRadius.circular(15),
                                        ),
                                        child: Container(
                                          height: 115,
                                          padding: const EdgeInsets.fromLTRB(16, 35, 17, 37),
                                          child: Container(
                                            decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/pngwing_5.png',
                                                ),
                                              ),
                                            ),
                                            child: const SizedBox(
                                              width: 82,
                                              height: 43,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 16, 26, 25),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text(
                                              'Fita Led J2',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12,
                                                color: const Color(0xFF747373),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 0, 12),
                                            child: Align(
                                              alignment: Alignment.topLeft,
                                              child: Text(
                                                'Status -',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 10,
                                                  color: const Color(0x8A7A7A7A),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFDBDBDB),
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Container(
                                              padding: const EdgeInsets.fromLTRB(0, 3, 3.8, 22),
                                              child: Text(
                                                'Saúde',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 9,
                                                  color: const Color(0xFFFFFFFF),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 29, 0, 29),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFFFFFFF),
                                        borderRadius: BorderRadius.circular(78),
                                      ),
                                      child: Container(
                                        width: 57,
                                        height: 57,
                                        padding: const EdgeInsets.fromLTRB(15, 14, 14, 14),
                                        child: SizedBox(
                                          width: 28,
                                          height: 29,
                                          child: SvgPicture.asset(
                                            'assets/vectors/vector_5_x2.svg',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              right: 83,
                              bottom: 10,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFFFFF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: SizedBox(
                                  width: 90,
                                  height: 36,
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(11, 10, 0, 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 9, 0),
                                          child: SizedBox(
                                            width: 19,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_4_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 1, 0, 0),
                                          child: Opacity(
                                            opacity: 0.8,
                                            child: Text(
                                              '100%',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 13,
                                                color: const Color(0xFF52A77A),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFFDBF2E6),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(11, 8, 32, 7),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 0, 25, 0),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFFFFFF),
                                          borderRadius: BorderRadius.circular(15),
                                        ),
                                        child: Container(
                                          height: 115,
                                          padding: const EdgeInsets.fromLTRB(17, 27, 17, 7),
                                          child: Container(
                                            decoration: const BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/pngwing_3.png',
                                                ),
                                              ),
                                            ),
                                            child: const SizedBox(
                                              width: 81,
                                              height: 81,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.fromLTRB(0, 16, 26, 25),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 15.6, 0),
                                            child: Text(
                                              'Lâmpada P1 - 2',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 12,
                                                color: const Color(0xFF747373),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: const EdgeInsets.fromLTRB(0, 0, 0, 12),
                                            child: Align(
                                              alignment: Alignment.topLeft,
                                              child: Text(
                                                'Status -',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 10,
                                                  color: const Color(0x8A7A7A7A),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFDBDBDB),
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Container(
                                              padding: const EdgeInsets.fromLTRB(0, 3, 3.8, 22),
                                              child: Text(
                                                'Saúde',
                                                style: GoogleFonts.getFont(
                                                  'Roboto Condensed',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 9,
                                                  color: const Color(0xFFFFFFFF),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.fromLTRB(0, 29, 0, 29),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFFFFFFF),
                                        borderRadius: BorderRadius.circular(78),
                                      ),
                                      child: Container(
                                        width: 57,
                                        height: 57,
                                        padding: const EdgeInsets.fromLTRB(15, 14, 14, 14),
                                        child: SizedBox(
                                          width: 28,
                                          height: 29,
                                          child: SvgPicture.asset(
                                            'assets/vectors/vector_36_x2.svg',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              right: 83,
                              bottom: 10,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFFFFF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: SizedBox(
                                  width: 90,
                                  height: 36,
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(11, 10, 0, 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 0, 9, 0),
                                          child: SizedBox(
                                            width: 19,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_21_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.fromLTRB(0, 1, 0, 0),
                                          child: Opacity(
                                            opacity: 0.8,
                                            child: Text(
                                              '100%',
                                              style: GoogleFonts.getFont(
                                                'Roboto Condensed',
                                                fontWeight: FontWeight.w500,
                                                fontSize: 13,
                                                color: const Color(0xFF52A77A),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: -19,
              right: -20,
              bottom: -57,
              child: Container(
                decoration: const BoxDecoration(
                  color: Color(0xFFD9D9D9),
                ),
                child: Stack(
                  children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    bottom: 0,
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Color(0xFFF8F8FB),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x26000000),
                            offset: Offset(0, -4),
                            blurRadius: 5,
                          ),
                        ],
                      ),
                      child: const SizedBox(
                        width: 395,
                        height: 85,
                      ),
                    ),
                  ),
            SizedBox(
                      width: 395,
                      height: 85,
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(0, 21, 0, 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 44,
                              height: 44,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_25_x2.svg',
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.fromLTRB(0, 7, 0, 7),
                              child: SizedBox(
                                width: 22,
                                height: 30,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_17_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}